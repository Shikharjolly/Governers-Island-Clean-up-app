* devices < 1440p => full width
* devices > 1440p => 80% width

* [X] added imgs
* [X] dunkin fonts
* [X] social media icons
